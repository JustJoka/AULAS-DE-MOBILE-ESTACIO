import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet, TextInput, Button, Alert } from 'react-native';
import styles from './styles';

export default function App() {
  const [ editandoId, setEditandoId ] = useState(null);
  const [alunos, setAlunos] = useState([]);
  const [loading, setLoading] = useState(true);

  const [nome, setNome] = useState('');
  const [idade, setIdade] = useState('');
  const [curso, setCurso] = useState('');

  const API_URL = 'https://68e3b9d88e14f4523dae73d8.mockapi.io/alunos';

  useEffect(() => {
    buscarAlunos();
 }, []);
 

  const buscarAlunos = async () => {
    try {
      const resposta = await fetch(API_URL);
      const dados = await resposta.json();
      setAlunos(dados);
    } catch (erro) {
      console.error('Erro ao buscar alunos:', erro);
    } finally {
      setLoading(false);
    }
  };

const adicionarAluno = async () => {
  if (!nome || !idade || !curso) {
    Alert.alert('Preencha todos os campos!');
    return;
  }

  try {
    const resposta = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json'},
      body: JSON.stringify({ nome, idade, curso}),
    });

    if (resposta.ok) {
      setNome('');
      setIdade('');
      setCurso('');
      buscarAlunos();
      Alert.alert('Aluno cadastrado com sucesso!');
    } else {
      Alert.alert('Erro ao cadastrar aluno');
    }
  } catch (erro) {
    console.error('Erro ao adicionar aluno', erro)
  }
};

if (loading) {
  return (
    <View style={styles.loadingContainer}>
      <ActivityIndicator size="large" color="#0066cc" />
      <Text> Carregando dados...</Text>
    </View>
);
}
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}> Lista de Alunos </Text>

      <View style={styles.form}>
        <TextInput
          placeholder="Nome"
          style={styles.input}
          value={nome}
          onChangeText={setNome}
        />
        <TextInput
          placeholder="Idade"
          style={styles.input}
          value={idade}
          onChangeText={setIdade}
        />
        <TextInput
          placeholder="Curso"
          style={styles.input}
          value={curso}
          onChangeText={setCurso}
        />
        <Button title="Adicionar Aluno" onPress={adicionarAluno} />
      </View>

      <FlatList
        data={alunos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text> Nome: {item.nome}</Text>
            <Text> Curso: {item.curso}</Text>
            <Text> Idade: {item.idade}</Text>
          </View>
        )}
      />
    </View>
  );
}





